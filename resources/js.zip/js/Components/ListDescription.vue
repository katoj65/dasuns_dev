<template>
<div class="card card-bordered">
<ul class="data-list is-compact">
<li class="data-item">
<div class="data-col">
<div class="data-label">First Name</div>
<div class="data-value">Abu Bin</div>
</div>
</li>
<li class="data-item">
<div class="data-col">
<div class="data-label">Last Name</div>
<div class="data-value">Ishtiyak</div>
</div>
</li>
<li class="data-item">
<div class="data-col">
<div class="data-label">Email Address</div>
<div class="data-value">info@softnio.com</div>
</div>
</li>
<li class="data-item">
<div class="data-col">
<div class="data-label">Phone Number</div>
<div class="data-value text-soft"><em>Not available</em></div>
</div>
</li>
<li class="data-item">
<div class="data-col">
<div class="data-label">Date of Birth</div>
<div class="data-value">28 Oct, 2015</div>
</div>
</li>
<li class="data-item">
<div class="data-col">
<div class="data-label">Full Address</div>
<div class="data-value">6516, Eldoret, Uasin Gishu, 30100</div>
</div>
</li>
<li class="data-item">
<div class="data-col">
<div class="data-label">Country of Residence</div>
<div class="data-value">Kenya</div>
</div>
</li>
<li class="data-item">
<div class="data-col">
<div class="data-label">Full Address</div>
<div class="data-value">6516, Eldoret, Uasin Gishu, 30100</div>
</div>
</li>
<li class="data-item">
<div class="data-col">
<div class="data-label">Wallet Type</div>
<div class="data-value">Bitcoin</div>
</div>
</li>
<li class="data-item">
<div class="data-col">
<div class="data-label">Wallet Address</div>
<div class="data-value text-break">1F1tAaz5x1HUXrCNLbtMDqcw6o5GNn4xqX</div>
</div>
</li>
<li class="data-item">
<div class="data-col">
<div class="data-label">Telegram</div>
<div class="data-value">
<span>@tokenlite</span> <a href="https://t.me/tokenlite" target="_blank"><em class="icon ni ni-telegram"></em></a>
</div>
</div>
</li>
</ul>
</div>
</template>

<script>
export default {
props:{
list:{}


}
}
</script>
