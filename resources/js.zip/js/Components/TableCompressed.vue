<template>
<div>

<table class="table table-tranx">

<tbody>
<tr class="tb-tnx-item">
<td class="tb-tnx-id">
<a href="#"><span>4947</span></a>
</td>
<td class="tb-tnx-info">
<div class="tb-tnx-desc">
<span class="title">Enterprize Year Subscrition</span>
</div>
<div class="tb-tnx-date">
<span class="date">10-05-2019</span>
<span class="date">10-13-2019</span>
</div>
</td>
<td class="tb-tnx-amount is-alt">
<div class="tb-tnx-total">
<span class="amount">$599.00</span>
</div>
<div class="tb-tnx-status">
<span class="badge badge-dot badge-warning">Due</span>
</div>
</td>
<td class="tb-tnx-action">
<div class="dropdown">
<a class="text-soft dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
<div class="dropdown-menu dropdown-menu-right dropdown-menu-xs">
<ul class="link-list-plain">
<li><a href="#">View</a></li>
<li><a href="#">Edit</a></li>
<li><a href="#">Remove</a></li>
</ul>
</div>
</div>
</td>
</tr><!-- tb-tnx-item -->
<tr class="tb-tnx-item">
<td class="tb-tnx-id">
<a href="#"><span>4904</span></a>
</td>
<td class="tb-tnx-info">
<div class="tb-tnx-desc">
<span class="title">Maintenance Year Subscription</span>
</div>
<div class="tb-tnx-date">
<span class="date">06-19-2019</span>
<span class="date">06-26-2019</span>
</div>
</td>
<td class="tb-tnx-amount is-alt">
<div class="tb-tnx-total">
<span class="amount">$99.00</span>
</div>
<div class="tb-tnx-status"><span class="badge badge-dot badge-success">Paid</span></div>
</td>
<td class="tb-tnx-action">
<div class="dropdown">
<a class="text-soft dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
<div class="dropdown-menu dropdown-menu-right dropdown-menu-xs">
<ul class="link-list-plain">
<li><a href="#">View</a></li>
<li><a href="#">Edit</a></li>
<li><a href="#">Remove</a></li>
</ul>
</div>
</div>
</td>
</tr><!-- tb-tnx-item -->
<tr class="tb-tnx-item">
<td class="tb-tnx-id">
<a href="#"><span>4829</span></a>
</td>
<td class="tb-tnx-info">
<div class="tb-tnx-desc">
<span class="title">Enterprize Year Subscrition</span>
</div>
<div class="tb-tnx-date">
<span class="date">10-04-2018</span>
<span class="date">10-12-2018</span>
</div>
</td>
<td class="tb-tnx-amount is-alt">
<div class="tb-tnx-total">
<span class="amount">$599.00</span>
</div>
<div class="tb-tnx-status"><span class="badge badge-dot badge-success">Paid</span></div>
</td>
<td class="tb-tnx-action">
<div class="dropdown">
<a class="text-soft dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
<div class="dropdown-menu dropdown-menu-right dropdown-menu-xs">
<ul class="link-list-plain">
<li><a href="#">View</a></li>
<li><a href="#">Edit</a></li>
<li><a href="#">Remove</a></li>
</ul>
</div>
</div>
</td>
</tr><!-- tb-tnx-item -->
<tr class="tb-tnx-item">
<td class="tb-tnx-id">
<a href="#"><span>4830</span></a>
</td>
<td class="tb-tnx-info">
<div class="tb-tnx-desc">
<span class="title">Enterprize Anniversary Subscription</span>
</div>
<div class="tb-tnx-date">
<span class="date">12-04-2018</span>
<span class="date">14-12-2018</span>
</div>
</td>
<td class="tb-tnx-amount is-alt">
<div class="tb-tnx-total">
<span class="amount">$399.00</span>
</div>
<div class="tb-tnx-status"><span class="badge badge-dot badge-success">Paid</span></div>
</td>
<td class="tb-tnx-action">
<div class="dropdown">
<a class="text-soft dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
<div class="dropdown-menu dropdown-menu-right dropdown-menu-xs">
<ul class="link-list-plain">
<li><a href="#">View</a></li>
<li><a href="#">Edit</a></li>
<li><a href="#">Remove</a></li>
</ul>
</div>
</div>
</td>
</tr><!-- tb-tnx-item -->
<tr class="tb-tnx-item">
<td class="tb-tnx-id">
<a href="#"><span>4840</span></a>
</td>
<td class="tb-tnx-info">
<div class="tb-tnx-desc">
<span class="title">Enterprize Coverage Subscription</span>
</div>
<div class="tb-tnx-date">
<span class="date">12-08-2018</span>
<span class="date">13-22-2018</span>
</div>
</td>
<td class="tb-tnx-amount is-alt">
<div class="tb-tnx-total">
<span class="amount">$99.00</span>
</div>
<div class="tb-tnx-status"><span class="badge badge-dot badge-danger">Cancel</span></div>
</td>
<td class="tb-tnx-action">
<div class="dropdown">
<a class="text-soft dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
<div class="dropdown-menu dropdown-menu-right dropdown-menu-xs">
<ul class="link-list-plain">
<li><a href="#">View</a></li>
<li><a href="#">Edit</a></li>
<li><a href="#">Remove</a></li>
</ul>
</div>
</div>
</td>
</tr><!-- tb-tnx-item -->
<tr class="tb-tnx-item">
<td class="tb-tnx-id">
<a href="#"><span>4844</span></a>
</td>
<td class="tb-tnx-info">
<div class="tb-tnx-desc">
<span class="title">Manual Subscription Adjustments</span>
</div>
<div class="tb-tnx-date">
<span class="date">12-08-2018</span>
<span class="date">13-22-2018</span>
</div>
</td>
<td class="tb-tnx-amount is-alt">
<div class="tb-tnx-total">
<span class="amount">$99.00</span>
</div>
<div class="tb-tnx-status"><span class="badge badge-dot badge-success">Paid</span></div>
</td>
<td class="tb-tnx-action">
<div class="dropdown">
<a class="text-soft dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
<div class="dropdown-menu dropdown-menu-right dropdown-menu-xs">
<ul class="link-list-plain">
<li><a href="#">View</a></li>
<li><a href="#">Edit</a></li>
<li><a href="#">Remove</a></li>
</ul>
</div>
</div>
</td>
</tr><!-- tb-tnx-item -->
<tr class="tb-tnx-item">
<td class="tb-tnx-id">
<a href="#"><span>4847</span></a>
</td>
<td class="tb-tnx-info">
<div class="tb-tnx-desc">
<span class="title">Automatic Subscription Adjustments</span>
</div>
<div class="tb-tnx-date">
<span class="date">12-08-2018</span>
<span class="date">13-22-2018</span>
</div>
</td>
<td class="tb-tnx-amount is-alt">
<div class="tb-tnx-total">
<span class="amount">$99.00</span>
</div>
<div class="tb-tnx-status"><span class="badge badge-dot badge-success">Paid</span></div>
</td>
<td class="tb-tnx-action">
<div class="dropdown">
<a class="text-soft dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
<div class="dropdown-menu dropdown-menu-right dropdown-menu-xs">
<ul class="link-list-plain">
<li><a href="#">View</a></li>
<li><a href="#">Edit</a></li>
<li><a href="#">Remove</a></li>
</ul>
</div>
</div>
</td>
</tr><!-- tb-tnx-item -->
<tr class="tb-tnx-item">
<td class="tb-tnx-id">
<a href="#"><span>4748</span></a>
</td>
<td class="tb-tnx-info">
<div class="tb-tnx-desc">
<span class="title">Tiered Subscription</span>
</div>
<div class="tb-tnx-date">
<span class="date">12-08-2018</span>
<span class="date">13-22-2018</span>
</div>
</td>
<td class="tb-tnx-amount is-alt">
<div class="tb-tnx-total">
<span class="amount">$99.00</span>
</div>
<div class="tb-tnx-status"><span class="badge badge-dot badge-success">Paid</span></div>
</td>
<td class="tb-tnx-action">
<div class="dropdown">
<a class="text-soft dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
<div class="dropdown-menu dropdown-menu-right dropdown-menu-xs">
<ul class="link-list-plain">
<li><a href="#">View</a></li>
<li><a href="#">Edit</a></li>
<li><a href="#">Remove</a></li>
</ul>
</div>
</div>
</td>
</tr><!-- tb-tnx-item -->
<tr class="tb-tnx-item">
<td class="tb-tnx-id">
<a href="#"><span>4748</span></a>
</td>
<td class="tb-tnx-info">
<div class="tb-tnx-desc">
<span class="title">Tiered Subscription</span>
</div>
<div class="tb-tnx-date">
<span class="date">12-08-2018</span>
<span class="date">13-22-2018</span>
</div>
</td>
<td class="tb-tnx-amount is-alt">
<div class="tb-tnx-total">
<span class="amount">$99.00</span>
</div>
<div class="tb-tnx-status"><span class="badge badge-dot badge-success">Paid</span></div>
</td>
<td class="tb-tnx-action">
<div class="dropdown">
<a class="text-soft dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
<div class="dropdown-menu dropdown-menu-right dropdown-menu-xs">
<ul class="link-list-plain">
<li><a href="#">View</a></li>
<li><a href="#">Edit</a></li>
<li><a href="#">Remove</a></li>
</ul>
</div>
</div>
</td>
</tr><!-- tb-tnx-item -->
<tr class="tb-tnx-item">
<td class="tb-tnx-id">
<a href="#"><span>4748</span></a>
</td>
<td class="tb-tnx-info">
<div class="tb-tnx-desc">
<span class="title">Flexible Subscription Plan</span>
</div>
<div class="tb-tnx-date">
<span class="date">12-08-2018</span>
<span class="date">13-22-2018</span>
</div>
</td>
<td class="tb-tnx-amount is-alt">
<div class="tb-tnx-total">
<span class="amount">$99.00</span>
</div>
<div class="tb-tnx-status"><span class="badge badge-dot badge-success">Paid</span></div>
</td>
<td class="tb-tnx-action">
<div class="dropdown">
<a class="text-soft dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
<div class="dropdown-menu dropdown-menu-right dropdown-menu-xs">
<ul class="link-list-plain">
<li><a href="#">View</a></li>
<li><a href="#">Edit</a></li>
<li><a href="#">Remove</a></li>
</ul>
</div>
</div>
</td>
</tr><!-- tb-tnx-item -->
</tbody>
</table>



</div>
</template>

<script>
export default {
props:{
head:{},
body:{},
options:{},
}
}
</script>
