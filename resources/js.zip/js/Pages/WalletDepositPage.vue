<template>
<app-layout>
<div class="row mt-3">
<div class="col-12 col-md-3"></div>
<div class="col-12 col-md-6 p-3">
<div class="card">
<div class="card-header">
<h6 class="card-title bold">Deposit Funds</h6>
</div>
<div class="card-body">

{{ api_data }}

<div class="card-inner border-radius p-3 m-0">
<ul class="nav nav-tabs mt-n3">
<li class="nav-item">
<a class="nav-link active" data-toggle="tab" href="#tabItem5">
<em class="icon ni ni-mobile"></em>
<span>Mobile Money</span></a>
</li>
<li class="nav-item">
<a class="nav-link" data-toggle="tab" href="#tabItem6">
<em class="icon ni ni-cc-alt"></em>
<span>Credit Card</span></a>
</li>

<li class="nav-item">
<a class="nav-link" data-toggle="tab" href="#tabItem7">
<em class="icon ni ni-coins"></em>

<span>Bank Transfer</span></a>
</li>
</ul>
<div class="tab-content" style="max-height:450px;overflow:hidden;">
<div class="tab-pane active" id="tabItem5">
<form @submit.prevent="submit1">
<div class="row gy-4">
<div>




</div>
<div class="col-sm-12">
<div class="form-group">
<label class="form-label" for="default-01">Mobile service Provider

<input-error :error="errors.type"></input-error>


</label>
<div class="form-control-wrap">
<select class="form-control" id="default-01" v-model="form1.type">
<option value="">Select</option>
<option v-for="m in payment_option.mobile.services" :key="m.name">
{{ m.name }}
</option>
</select>
</div>
</div>
</div>

<div class="col-sm-12">
<div class="form-group">
<label class="form-label" for="default-01">Telephone Number

    <input-error :error="errors.tel"></input-error>
</label>
<div class="form-control-wrap">
<input type="number" class="form-control" id="default-01" placeholder="Enter telephone number" v-model="form1.tel">
</div>
</div>
</div>


<div class="col-sm-12">
<div class="form-group">
<label class="form-label" for="default-01">Amount <input-error :error="errors.amount"></input-error></label>
<div class="form-control-wrap">
<input type="text" class="form-control" id="default-01" placeholder="Enter amount" v-model="form1.amount">
</div>
</div>
</div>





<div class="col-sm-12">
<div class="form-group">
<button class="btn button" style="font-size:18px;">
Deposit to Wallet
</button>
</div>
</div>



</div>
</form>
</div>
<div class="tab-pane" id="tabItem6">
<p>
{{payment_option.card.instructions}}
</p>
</div>
<div class="tab-pane" id="tabItem7">
<p>
{{payment_option.bank.instructions}}
</p>
</div>
</div>
</div>





</div>
</div>

</div>
<div class="col-12 col-md-3"></div>



</div>
</app-layout>
</template>
<script>
import AppLayout from '../Layouts/AppLayout.vue';
import InputError from '../Alerts/InputError.vue';
import axios from 'axios';
export default {
props:{
title:{},
response:{},
errors:{}





},
components:{
AppLayout,
InputError
},
data(){return{
modal:false,
flash:null,
api_data:null,



//
payment_option:{
//mobile payment
mobile:{

instructions:'Credit card Culpa dolor voluptate do laboris laboris irure reprehenderit id incididunt duis pariatur mollit aute magna pariatur consectetur. Eu veniam duis non ut dolor deserunt commodo et minim in quis',
//services list

services:[

{name:'MTN'},
{name:'Airtel'},
{name:'Other'}

],



},
//card payment
card:{

instructions:'Credit card Culpa dolor voluptate do laboris laboris irure reprehenderit id incididunt duis pariatur mollit aute magna pariatur consectetur. Eu veniam duis non ut dolor deserunt commodo et minim in quis',
//services list

services:[

{name:'Paypal'},
{name:'Master Card'},

]
},

//bank payment
bank:{

instructions:'Credit card Culpa dolor voluptate do laboris laboris irure reprehenderit id incididunt duis pariatur mollit aute magna pariatur consectetur. Eu veniam duis non ut dolor deserunt commodo et minim in quis',
//services list

services:[

{name:'Centenary Bank'},
{name:'DFCU Bank'},
{name:'UBA Bank'},
{name:'Bank of Africa'},

]

}






},

form1:this.$inertia.form({
type:'',
tel:'',
amount:'',
password:''
}),






}},


methods:{
submit1(){
this.flash=this.$page.props.flash;
this.errors=this.$page.props.errors;

// this.form1.post(this.route('wallet-deposit'),{
// onSuccess:()=>{
// this.modal=false;
// this.form1.reset();
// this.$notify({
// title:'Successful',
// message:flash.success,
// type:'success',
// position:'bottom-right'

// });

// }
// });


const data = JSON.stringify({
"consumer_key": "8gZ6+scc8ndQ/RtfLIoh3UMG0xX5EO2x",
"consumer_secret": "hBUJkdS5VjPl1Ovu/06IFtT4GT4="
});

const config = {
method: 'post',
maxBodyLength: Infinity,
url: 'https://cybqa.pesapal.com/pesapalv3/api/Auth/RequestToken',
headers: {
'Content-Type': 'application/json',
'Accept': 'application/json'
},
data : data
};



axios(config)
.then(function (response) {
  console.log(JSON.stringify(response.data));
})
.catch(function (error) {
  console.log(error);
});


},








},


}
</script>
