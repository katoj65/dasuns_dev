<template>
<LayoutUnAuth>
<div class="nk-content nk-content-lg nk-content-fluid" style="min-height:600px;">
<div class="container-xl wide-lg">
<div class="nk-content-inner">
<div class="nk-content-body">
<h1 style="text-align:center;font-weight:bolder;font-size:20px;word-spacing:5px;line-height:50px;font-family: Arial, Helvetica, sans-serif;">
We Provide Support Services
</h1>
<div class="row">
<div class="col-md-2 col-12"></div>
<div class="col-md-8 col-12" >

<p>
We facilitatesfacilitate access to professional support service through a digital
platform (Dasuns) that connects providers with users. Users could choose the type of
service by interacting through a digital system.
Service providers and users only need to sign up for an account once. Users can
then log on to the system and request for their preferred support service from
available service providers within reach.
</p>


<h4 class="mt-3">
We Provide Refresher Trainings to Service Providers
</h4>

<p class="mt-3">
While we acknowledge that most support service providers have their training
backgrounds from Universities and other tertiary institutions, we work with
Organisations of Persons with Disabilities to enhance their professional skills and
further have them go through a vetting process before we could onboard them on
Dasuns Digital Platform as support service providers.
</p>

<h4 class="mt-3">
Strengthen Community Capacity on Disability inclusive
programming in education &amp; employment
</h4>
<p class="mt-3">
Awareness of disability-inclusive development is increasing globally. However, we
believe that Uunless deliberate measures are considered, persons with disabilities
are more most likely to experience adverse socioeconomic outcomes such as less
education, poorer health outcomes, lower levels of employment, and higher poverty
rates.
</p>


<p class="mt-3">
The United Nations Convention on the Rights of Persons with Disabilities (CRPD)
promotes the full integration of persons with disabilities in societies on an equal basis
with others; and the 2030 Agenda for Sustainable Development clearly states that
disability cannot be a reason or criteria for lack of access to development
programming and the realization of human rights.
</p>

<p class="mt-3">
We support development planning teams to identify, analyse, include, monitor, and
evaluate disability issues as an integral part of their plansning and budgeting
processess.
</p>

<h4 class="mt-3">
Empower young men and women with disabilities to acquire ICT and related employable skills
</h4>
<p class="mt-3">
Information and Communication Technology skill development is an important
strategy for the social inclusion of persons with disabilities in the mainstream of
community life. Effective participation in educational, employment and social
opportunities may be dependent upon being able to make use of computers and the
internet. For many young men and women with disabilities, these opportunities can
be particularly important. Many of them could exploit learning opportunities on-line,
work from home, and/or make contact with services, friends, family and support
networks.
</p>


<p class="mt-3">
However, many of these young men and women with disabilities persons with
disabilities have not had the opportunity to acquire such relevant skills to compete
favourably in the evolving digital world.
</p>
<p>
We work to empower young men and women with disabilities with the ICT skills and
knowledge they need to succeed.
</p>






<div>






</div>


</div>
<div class="col-md-2 col-12"></div>
</div>
</div>
</div>
</div>
</div>
</LayoutUnAuth>
</template>
<script>
import LayoutUnAuth from '@/Layouts/LayoutUnAuth'
export default {
components:{
LayoutUnAuth


},
props:{
title:{},
response:{}
},
data(){return {









}}






}
</script>


<style scoped>
h4{font-size:20px;
line-height: 30px;
}
p{font-size:15px;}


</style>
