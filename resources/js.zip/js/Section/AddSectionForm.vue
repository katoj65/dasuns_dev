<template>


</template>
<script>
export default {
    components:{},
    props:{
    pages:{},
    errors:{},
    flash:{}
    },
    data(){return{
    show:false,








    }},


    methods:{





    },

    computed:{





        
    }
}
</script>
