<template>
    <app-layout>
    <div class="mt-2">
        <div class="nk-block-head nk-block-head-sm">
            <div class="nk-block-between">
                <div class="nk-block-head-content">
                    <h3 class="nk-block-title page-title"><em class="icon ni ni-view-x6"></em> Support Services</h3>
                    <div class="nk-block-des text-soft">

                    </div>
                </div><!-- .nk-block-head-content -->

            </div><!-- .nk-block-between -->
        </div>





    <div class="row">
    <div class="col-md-3 mb-4">


    </div>

















    </div>







    </div>







    </app-layout>
    </template>

    <script>

    import AppLayout from '@/Layouts/AppLayout';

        export default {
        components:{
        AppLayout,


        },
        props:{
        title:{},
        response:{},
        },
        data(){return{


        }},


        //computed method
    computed:{
  



        }







        }
        </script>
