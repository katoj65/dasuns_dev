<template>
    <div>
    Some conten
    </div>
</template>
<script>
export default {
    props:{
    response:{},
    }
}
</script>
