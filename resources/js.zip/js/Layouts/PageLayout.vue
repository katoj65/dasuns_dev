<template>
<AppLayout>

</AppLayout>
</template>
<script>
import AppLayout from './AppLayout.vue';
export default {
components:{
AppLayout,
},
props:{
response:{},
title:{},
    },
}


