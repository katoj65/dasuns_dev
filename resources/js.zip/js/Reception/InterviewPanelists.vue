<template>
<div>

Some information

</div>
</template>

<script>
export default {
    props:{
    panelist:{}
    },


}
</script>
