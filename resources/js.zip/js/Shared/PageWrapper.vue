<template>
<div>
<slot></slot>
</div>
</template>

<script>
export default {
//page wrapper information
}
</script>
