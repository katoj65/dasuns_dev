<template>

</template>
<script>
export default {
    props:{
        response:{}
    },

data(){return{





}},
methods:{

    
}




}
</script>
